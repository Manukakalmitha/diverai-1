const n=b;(function(x,r){const a=b,e=x();for(;;)try{if(parseInt(a(392))/1+parseInt(a(364))/2*(-parseInt(a(393))/3)+-parseInt(a(342))/4*(parseInt(a(397))/5)+parseInt(a(368))/6+parseInt(a(389))/7*(parseInt(a(347))/8)+parseInt(a(361))/9*(-parseInt(a(357))/10)+parseInt(a(387))/11===r)break;e.push(e.shift())}catch{e.push(e.shift())}})(s,416709);const d=document.createElement(n(354));d[n(388)]=n(395),document.head[n(370)](d);function b(x,r){return x=x-342,s()[x]}function l(){const x=n;if(document[x(374)](".diver-ai-btn"))return;const r=[x(371),"#header-toolbar-symbol-search",x(366),"#ybar-inner-wrap","header",x(358)];let a=null;for(const t of r){const o=document[x(374)](t);if(o){a=o;break}}const e=document[x(355)]("button");e[x(367)]=x(377);const i=chrome[x(363)][x(356)](x(375));e.innerHTML='<img src="'+i+x(353),e[x(354)][x(372)]=x(359),e[x(354)][x(348)]=x(391),e.style[x(365)]=x(384),e[x(354)][x(378)]=x(384),e[x(354)].backgroundColor=x(351),e.style[x(346)]=x(352),e[x(354)][x(385)]=x(380),e[x(354)][x(349)]=x(344),e[x(354)][x(379)]=x(381),e[x(343)]=()=>{const t=x;try{chrome.runtime[t(390)]({action:t(360)},o=>{const c=t;chrome[c(363)].lastError&&console[c(382)](c(394))})}catch{console[t(382)](t(386))}},a?a[x(370)](e):(e[x(354)][x(345)]="fixed",e[x(354)].bottom=x(373),e[x(354)].right=x(373),e[x(354)][x(376)]=x(369),e[x(354)][x(362)]=x(350),document[x(383)][x(370)](e))}const p=new MutationObserver(x=>{l()});p[n(396)](document[n(383)],{childList:!0,subtree:!0}),setTimeout(l,2e3);function s(){const x=["OPEN_SIDEBAR","27uYvyLt","boxShadow","runtime","503390fIWjFy","alignItems","#header-wrapper","className","1671960UhPFAP","2147483647","appendChild",'[class*="layout-header"] [class*="group-left"]',"padding","20px","querySelector","pulse-icon.png","zIndex","diver-ai-btn","justifyContent","backdropFilter","12px","blur(8px)","debug","body","center","borderRadius","DiverAI: Message sending failed (likely extension context invalidated).","4950176OJUdFb","textContent","217ftJuit","sendMessage","flex","548206QduyPd","3EBUjLk","DiverAI: Connection to background script lost/pending. Re-injection may be needed.",`
  .diver-ai-btn {
    background: #1e293b;
    color: #f8fafc;
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 8px;
    cursor: pointer;
    margin-left: 10px;
    font-family: -apple-system, BlinkMacSystemFont, "Trebuchet MS", Roboto, Ubuntu, sans-serif;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 9999;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  }
  .diver-ai-btn:hover {
    background: #334155;
    transform: scale(1.05) translateY(-2px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6), 0 0 0 1px #10b981;
  }
  .diver-ai-btn:active {
    transform: scale(0.95);
  }
  @keyframes heartbeat {
    0% { transform: scale(1); }
    15% { transform: scale(1.1); }
    30% { transform: scale(1); }
    45% { transform: scale(1.15); }
    70% { transform: scale(1); }
  }
  .diver-ai-btn img {
    animation: heartbeat 3s infinite ease-in-out;
  }
`,"observe","40pZHhGr","139732xtbxBa","onclick","all 0.3s cubic-bezier(0.4, 0, 0.2, 1)","position","border","116224YAKwsF","display","transition","0 4px 14px rgba(0,0,0,0.4)","#1e293b","1px solid #334155",'" alt="DiverAI" style="height: 24px; width: 24px; vertical-align: middle; pointer-events:none; border-radius: 6px;" />',"style","createElement","getURL","2597940IMdcLr",".header-main","8px"];return s=function(){return x},s()}
