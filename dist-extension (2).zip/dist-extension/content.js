const n=b;(function(x,r){const a=b,e=x();for(;;)try{if(-parseInt(a(406))/1*(parseInt(a(414))/2)+-parseInt(a(398))/3+-parseInt(a(400))/4*(-parseInt(a(428))/5)+parseInt(a(391))/6*(parseInt(a(425))/7)+-parseInt(a(392))/8*(parseInt(a(448))/9)+parseInt(a(402))/10+-parseInt(a(397))/11*(parseInt(a(432))/12)===r)break;e.push(e.shift())}catch{e.push(e.shift())}})(s,518275);const d=document.createElement(n(426));function s(){const x=["textContent",'[class*="layout-header"] [class*="group-left"]',"backgroundColor",'<img src="',`
  .diver-ai-btn {
    background: #1e293b;
    color: #f8fafc;
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 8px;
    cursor: pointer;
    margin-left: 10px;
    font-family: -apple-system, BlinkMacSystemFont, "Trebuchet MS", Roboto, Ubuntu, sans-serif;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 9999;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  }
  .diver-ai-btn:hover {
    background: #334155;
    transform: scale(1.05) translateY(-2px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6), 0 0 0 1px #10b981;
  }
  .diver-ai-btn:active {
    transform: scale(0.95);
  }
  @keyframes heartbeat {
    0% { transform: scale(1); }
    15% { transform: scale(1.1); }
    30% { transform: scale(1); }
    45% { transform: scale(1.15); }
    70% { transform: scale(1); }
  }
  .diver-ai-btn img {
    animation: heartbeat 3s infinite ease-in-out;
  }
`,"diver-ai-btn","observe","right","className","blur(8px)","81YlAOWa","querySelector","appendChild","1696614HAYCvc","172608GFHwlt","justifyContent",".diver-ai-btn","head",".header-main","55BDkPTe","2521710drpVti","#ybar-inner-wrap","4BRIXpm","12px","10000440yyrBdw","2147483647","getURL","20px","1fyobcE","debug","center","OPEN_SIDEBAR","body","boxShadow","1px solid #334155","runtime","415736WEeIoK","innerHTML","display","alignItems","flex","sendMessage","fixed","8px","DiverAI: Message sending failed (likely extension context invalidated).","#header-toolbar-symbol-search","pulse-icon.png","21cPgHwC","style","lastError","709705FIrxWU","#header-wrapper","backdropFilter","DiverAI: Connection to background script lost/pending. Re-injection may be needed.","550548wwcMMf","header","transition","zIndex","border",'" alt="DiverAI" style="height: 24px; width: 24px; vertical-align: middle; pointer-events:none; border-radius: 6px;" />'];return s=function(){return x},s()}function b(x,r){return x=x-390,s()[x]}d[n(438)]=n(442),document[n(395)][n(390)](d);function l(){const x=n;if(document[x(449)](x(394)))return;const r=[x(439),x(423),x(429),x(399),x(433),x(396)];let a=null;for(const t of r){const o=document.querySelector(t);if(o){a=o;break}}const e=document.createElement("button");e[x(446)]=x(443);const i=chrome[x(413)][x(404)](x(424));e[x(415)]=x(441)+i+x(437),e[x(426)].padding=x(421),e[x(426)][x(416)]=x(418),e[x(426)][x(417)]="center",e[x(426)][x(393)]=x(408),e[x(426)][x(440)]="#1e293b",e[x(426)][x(436)]=x(412),e[x(426)].borderRadius=x(401),e[x(426)][x(434)]="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",e.style[x(430)]=x(447),e.onclick=()=>{const t=x;try{chrome[t(413)][t(419)]({action:t(409)},o=>{const c=t;chrome.runtime[c(427)]&&console[c(407)](c(431))})}catch{console[t(407)](t(422))}},a?a[x(390)](e):(e[x(426)].position=x(420),e[x(426)].bottom=x(405),e[x(426)][x(445)]="20px",e[x(426)][x(435)]=x(403),e[x(426)][x(411)]="0 4px 14px rgba(0,0,0,0.4)",document[x(410)][x(390)](e))}const p=new MutationObserver(x=>{l()});p[n(444)](document[n(410)],{childList:!0,subtree:!0}),setTimeout(l,2e3);
